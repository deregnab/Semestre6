somme n = sum [1..n]
